import { ConfigService } from '@nestjs/config';
import { ExecutionEngineService } from '../src/modules/graph/execution-engine.service';
import { ExpressionEvaluator } from '../src/modules/graph/expression-evaluator';
import { compiledFixture } from './graph.fixture';

describe('ExecutionEngineService', () => {
  const engine = new ExecutionEngineService(
    new ExpressionEvaluator(),
    new ConfigService({ MAX_EXECUTION_STEPS: 32 }),
  );

  it('approves when the conditional edge matches', () => {
    const result = engine.execute(compiledFixture(), { score: 700 });
    expect(result.outcome).toBe('APPROVED');
    expect(result.reasons.map((reason) => reason.code)).toEqual(['APPROVED_POLICY']);
    expect(result.visitedNodeKeys).toEqual(['START', 'CHECK', 'APPROVED']);
    expect(result.traversedEdgeKeys).toEqual(['START_CHECK', 'CHECK_APPROVE']);
  });

  it('uses the explicit default edge when conditions do not match', () => {
    const result = engine.execute(compiledFixture(), { score: 500 });
    expect(result.outcome).toBe('DECLINED');
    expect(result.reasons[0].adverseAction).toBe(true);
    expect(result.terminalNodeKey).toBe('DECLINED');
  });

  it('returns identical business output for the same input', () => {
    const first = engine.execute(compiledFixture(), { score: 700 });
    const second = engine.execute(compiledFixture(), { score: 700 });
    expect({ ...first, trace: undefined }).toEqual({ ...second, trace: undefined });
  });
});
