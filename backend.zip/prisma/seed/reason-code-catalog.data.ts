import type { ReasonSeed } from './types';

// Catálogo maestro de reason codes (motivos de decisión) que se mantiene en
// producción como dato de referencia para explicabilidad y adverse action notices.

const kyc: ReasonSeed[] = [
  { code: 'KYC_OR_CONSENT_INVALID', category: 'KYC', publicMessage: 'No fue posible aprobar la solicitud por requisitos de identificación o consentimiento.', internalMessage: 'KYC no verificado o consentimiento inactivo.', adverseAction: true },
  { code: 'DOCUMENT_EXPIRED', category: 'KYC', publicMessage: 'El documento de identidad presentado se encuentra vencido.', internalMessage: 'document_expiry_date anterior a la fecha de evaluación.', adverseAction: true },
  { code: 'DOCUMENT_ILLEGIBLE', category: 'KYC', publicMessage: 'No fue posible validar el documento de identidad presentado.', internalMessage: 'La captura del documento no permitió extracción confiable de datos.', adverseAction: true },
  { code: 'BIOMETRIC_MATCH_FAILED', category: 'KYC', publicMessage: 'No fue posible confirmar tu identidad con la foto proporcionada.', internalMessage: 'biometric_match_score por debajo del umbral mínimo requerido.', adverseAction: true },
  { code: 'LIVENESS_CHECK_FAILED', category: 'KYC', publicMessage: 'No fue posible completar la verificación de identidad en vivo.', internalMessage: 'liveness_check_passed=false.', adverseAction: true },
  { code: 'ADDRESS_NOT_VERIFIED', category: 'KYC', publicMessage: 'No fue posible confirmar el domicilio declarado.', internalMessage: 'address_verified=false y sin comprobante alternativo válido.', adverseAction: true },
  { code: 'PHONE_NOT_VERIFIED', category: 'KYC', publicMessage: 'No fue posible confirmar el número de teléfono proporcionado.', internalMessage: 'phone_verified=false tras los intentos permitidos.', adverseAction: false },
  { code: 'EMAIL_NOT_VERIFIED', category: 'KYC', publicMessage: 'No fue posible confirmar el correo electrónico proporcionado.', internalMessage: 'email_verified=false tras los intentos permitidos.', adverseAction: false },
  { code: 'PEP_MANUAL_REVIEW_REQUIRED', category: 'KYC', publicMessage: 'Tu solicitud requiere una revisión adicional antes de continuar.', internalMessage: 'pep_status=true; se deriva a revisión reforzada de debida diligencia.', adverseAction: false },
  { code: 'IDENTITY_CONFIDENCE_LOW', category: 'KYC', publicMessage: 'No fue posible confirmar tu identidad con la información proporcionada.', internalMessage: 'identity_confidence_score por debajo del umbral mínimo.', adverseAction: true },
  { code: 'MINOR_APPLICANT', category: 'KYC', publicMessage: 'La solicitud no cumple el requisito de mayoría de edad.', internalMessage: 'age menor al mínimo legal permitido.', adverseAction: true },
  { code: 'DUPLICATE_IDENTITY_DETECTED', category: 'KYC', publicMessage: 'Ya existe una solicitud activa asociada a esta identidad.', internalMessage: 'Se detectó un documento de identidad duplicado en otra solicitud activa.', adverseAction: false },
  { code: 'RESIDENCY_NOT_ELIGIBLE', category: 'KYC', publicMessage: 'Tu estatus de residencia no es elegible para este producto.', internalMessage: 'residency_status fuera de las categorías aceptadas por política.', adverseAction: true },
];

const fraud: ReasonSeed[] = [
  { code: 'FRAUD_REVIEW_REQUIRED', category: 'FRAUD', publicMessage: 'La solicitud requiere una revisión adicional.', internalMessage: 'Se detectó señal crítica de fraude; se deriva a revisión manual.', adverseAction: false },
  { code: 'DEVICE_BLOCKLISTED', category: 'FRAUD', publicMessage: 'No fue posible procesar la solicitud desde este dispositivo.', internalMessage: 'device_reputation=BLOCKLISTED.', adverseAction: true },
  { code: 'KNOWN_FRAUD_DEVICE', category: 'FRAUD', publicMessage: 'La solicitud requiere una revisión adicional.', internalMessage: 'known_fraud_device_flag=true.', adverseAction: false },
  { code: 'KNOWN_FRAUD_EMAIL', category: 'FRAUD', publicMessage: 'La solicitud requiere una revisión adicional.', internalMessage: 'known_fraud_email_flag=true.', adverseAction: false },
  { code: 'KNOWN_FRAUD_PHONE', category: 'FRAUD', publicMessage: 'La solicitud requiere una revisión adicional.', internalMessage: 'known_fraud_phone_flag=true.', adverseAction: false },
  { code: 'SYNTHETIC_IDENTITY_SUSPECTED', category: 'FRAUD', publicMessage: 'No fue posible validar la identidad proporcionada.', internalMessage: 'synthetic_identity_score por encima del umbral crítico.', adverseAction: true },
  { code: 'VELOCITY_LIMIT_EXCEEDED', category: 'FRAUD', publicMessage: 'Se alcanzó el límite de solicitudes permitidas en el período.', internalMessage: 'velocity_applications_24h o velocity_applications_7d excede el umbral.', adverseAction: false },
  { code: 'SIM_SWAP_DETECTED', category: 'FRAUD', publicMessage: 'La solicitud requiere una revisión adicional de seguridad.', internalMessage: 'sim_swap_detected=true en las últimas 72 horas.', adverseAction: false },
  { code: 'HIGH_RISK_IP', category: 'FRAUD', publicMessage: 'No fue posible procesar la solicitud desde esta conexión.', internalMessage: 'ip_address_risk_score por encima del umbral o ip_tor_detected=true.', adverseAction: true },
  { code: 'GEOLOCATION_MISMATCH', category: 'FRAUD', publicMessage: 'La solicitud requiere una revisión adicional.', internalMessage: 'geolocation_mismatch_flag=true entre domicilio declarado e IP.', adverseAction: false },
  { code: 'DEVICE_TAMPERING_DETECTED', category: 'FRAUD', publicMessage: 'No fue posible procesar la solicitud desde este dispositivo.', internalMessage: 'os_jailbreak_detected o app_tampering_detected=true.', adverseAction: true },
  { code: 'PREVIOUS_FRAUD_CASE', category: 'FRAUD', publicMessage: 'No fue posible aprobar la solicitud con la información proporcionada.', internalMessage: 'previous_fraud_case_flag=true en el historial del cliente.', adverseAction: true },
  { code: 'ACCOUNT_TAKEOVER_RISK', category: 'FRAUD', publicMessage: 'La solicitud requiere una revisión adicional de seguridad.', internalMessage: 'account_takeover_risk_score por encima del umbral crítico.', adverseAction: false },
  { code: 'AUTOMATION_DETECTED', category: 'FRAUD', publicMessage: 'No fue posible procesar la solicitud.', internalMessage: 'browser_automation_detected=true durante la sesión.', adverseAction: true },
];

const creditRisk: ReasonSeed[] = [
  { code: 'RISK_THRESHOLD_NOT_MET', category: 'CREDIT_RISK', publicMessage: 'La solicitud no alcanza el perfil de riesgo requerido.', internalMessage: 'Puntaje de riesgo inferior al umbral de aprobación.', adverseAction: true },
  { code: 'BUREAU_SCORE_TOO_LOW', category: 'CREDIT_RISK', publicMessage: 'Tu puntaje crediticio no alcanza el mínimo requerido.', internalMessage: 'bureau_score por debajo del umbral mínimo de política.', adverseAction: true },
  { code: 'EXCESSIVE_DELINQUENCY_HISTORY', category: 'CREDIT_RISK', publicMessage: 'Tu historial crediticio muestra pagos atrasados recientes.', internalMessage: 'delinquency_count_12m excede el máximo permitido.', adverseAction: true },
  { code: 'RECENT_BANKRUPTCY', category: 'CREDIT_RISK', publicMessage: 'Tu historial crediticio no cumple los requisitos actuales.', internalMessage: 'bankruptcy_flag=true dentro del período de exclusión de política.', adverseAction: true },
  { code: 'RECENT_CHARGE_OFF', category: 'CREDIT_RISK', publicMessage: 'Tu historial crediticio no cumple los requisitos actuales.', internalMessage: 'charge_off_count mayor a cero dentro del período evaluado.', adverseAction: true },
  { code: 'ACTIVE_COLLECTIONS_BALANCE', category: 'CREDIT_RISK', publicMessage: 'Se identificaron cuentas en cobranza activas.', internalMessage: 'collections_balance excede el umbral permitido por política.', adverseAction: true },
  { code: 'HIGH_REVOLVING_UTILIZATION', category: 'CREDIT_RISK', publicMessage: 'Tu nivel de utilización de crédito actual es elevado.', internalMessage: 'revolving_utilization_ratio excede el umbral de política.', adverseAction: true },
  { code: 'THIN_CREDIT_FILE', category: 'CREDIT_RISK', publicMessage: 'No contamos con historial crediticio suficiente para evaluar la solicitud.', internalMessage: 'thin_file_flag=true o no_hit_flag=true.', adverseAction: true },
  { code: 'EXCESSIVE_RECENT_INQUIRIES', category: 'CREDIT_RISK', publicMessage: 'Se registraron múltiples solicitudes de crédito recientes.', internalMessage: 'inquiries_last_6m excede el umbral permitido por política.', adverseAction: true },
  { code: 'HIGH_DEBT_TO_INCOME', category: 'CREDIT_RISK', publicMessage: 'Tu nivel de endeudamiento actual excede lo permitido para este producto.', internalMessage: 'debt_to_income_ratio excede el umbral de política.', adverseAction: true },
  { code: 'PUBLIC_RECORDS_PRESENT', category: 'CREDIT_RISK', publicMessage: 'Tu historial crediticio muestra registros públicos adversos.', internalMessage: 'public_records_count mayor a cero.', adverseAction: true },
  { code: 'REPOSSESSION_HISTORY', category: 'CREDIT_RISK', publicMessage: 'Tu historial crediticio no cumple los requisitos actuales.', internalMessage: 'repossession_history_flag=true dentro del período de exclusión.', adverseAction: true },
  { code: 'CREDIT_MIX_INSUFFICIENT', category: 'CREDIT_RISK', publicMessage: 'Tu historial crediticio no muestra suficiente diversidad de productos.', internalMessage: 'credit_mix_score por debajo del umbral mínimo.', adverseAction: false },
  { code: 'PAYMENT_HISTORY_WEAK', category: 'CREDIT_RISK', publicMessage: 'Tu historial de pagos no alcanza el mínimo requerido.', internalMessage: 'payment_history_score por debajo del umbral mínimo.', adverseAction: true },
  { code: 'RISK_BAND_HIGH', category: 'CREDIT_RISK', publicMessage: 'La solicitud fue clasificada en una banda de riesgo elevada.', internalMessage: 'Modelo de score asignó risk_band=HIGH.', adverseAction: false },
];

const eligibility: ReasonSeed[] = [
  { code: 'AGE_NOT_ELIGIBLE', category: 'ELIGIBILITY', publicMessage: 'La solicitud no cumple los requisitos de elegibilidad.', internalMessage: 'Edad fuera de la política vigente.', adverseAction: true },
  { code: 'JURISDICTION_NOT_SUPPORTED', category: 'ELIGIBILITY', publicMessage: 'El producto no está disponible en tu jurisdicción actual.', internalMessage: 'regulatory_jurisdiction no habilitada para el producto.', adverseAction: false },
  { code: 'EMPLOYMENT_STATUS_NOT_ELIGIBLE', category: 'ELIGIBILITY', publicMessage: 'Tu situación laboral actual no es elegible para este producto.', internalMessage: 'employment_status fuera de las categorías aceptadas por política.', adverseAction: true },
  { code: 'PRODUCT_AMOUNT_OUT_OF_RANGE', category: 'ELIGIBILITY', publicMessage: 'El monto solicitado está fuera del rango disponible para este producto.', internalMessage: 'requested_amount fuera de los límites configurados del producto.', adverseAction: false },
  { code: 'TERM_OUT_OF_RANGE', category: 'ELIGIBILITY', publicMessage: 'El plazo solicitado está fuera del rango disponible para este producto.', internalMessage: 'requested_term_months fuera de los límites configurados del producto.', adverseAction: false },
  { code: 'EXISTING_ACTIVE_LOAN', category: 'ELIGIBILITY', publicMessage: 'Ya cuentas con una obligación activa que impide una nueva solicitud.', internalMessage: 'Cliente posee una obligación activa incompatible con la política de concurrencia.', adverseAction: true },
  { code: 'CHANNEL_NOT_ELIGIBLE', category: 'ELIGIBILITY', publicMessage: 'Este producto no está disponible por el canal utilizado.', internalMessage: 'application_channel no habilitado para el producto solicitado.', adverseAction: false },
  { code: 'DEPENDENTS_COUNT_INCOMPLETE', category: 'ELIGIBILITY', publicMessage: 'Falta información sobre dependientes económicos para continuar.', internalMessage: 'dependents_count no informado y requerido por política.', adverseAction: false },
  { code: 'RESIDENCY_TENURE_INSUFFICIENT', category: 'ELIGIBILITY', publicMessage: 'El tiempo de residencia declarado no cumple el mínimo requerido.', internalMessage: 'years_at_current_address por debajo del mínimo de política.', adverseAction: true },
  { code: 'EMPLOYMENT_TENURE_INSUFFICIENT', category: 'ELIGIBILITY', publicMessage: 'La antigüedad laboral declarada no cumple el mínimo requerido.', internalMessage: 'years_at_current_employer por debajo del mínimo de política.', adverseAction: true },
  { code: 'NATIONALITY_RESTRICTED', category: 'ELIGIBILITY', publicMessage: 'El producto no está disponible para tu nacionalidad declarada.', internalMessage: 'nationality incluida en la lista de restricciones del producto.', adverseAction: true },
  { code: 'MARITAL_STATUS_DOCUMENTATION_REQUIRED', category: 'ELIGIBILITY', publicMessage: 'Se requiere documentación adicional sobre tu estado civil para continuar.', internalMessage: 'marital_status=MARRIED requiere consentimiento conyugal según política local.', adverseAction: false },
];

const affordability: ReasonSeed[] = [
  { code: 'AFFORDABILITY_RATIO_EXCEEDED', category: 'AFFORDABILITY', publicMessage: 'La cuota estimada excede tu capacidad de pago actual.', internalMessage: 'affordability_ratio excede el umbral máximo de política.', adverseAction: true },
  { code: 'INCOME_NOT_VERIFIED', category: 'AFFORDABILITY', publicMessage: 'No fue posible verificar el ingreso declarado.', internalMessage: 'income_verification_method no concluyó con evidencia suficiente.', adverseAction: true },
  { code: 'INSUFFICIENT_DISPOSABLE_INCOME', category: 'AFFORDABILITY', publicMessage: 'Tu ingreso disponible no alcanza para la cuota solicitada.', internalMessage: 'disposable_income insuficiente frente a la cuota estimada.', adverseAction: true },
  { code: 'NSF_HISTORY_EXCESSIVE', category: 'AFFORDABILITY', publicMessage: 'Se identificaron rechazos recientes por fondos insuficientes.', internalMessage: 'bank_statement_nsf_count excede el umbral permitido.', adverseAction: true },
  { code: 'INCOME_STABILITY_LOW', category: 'AFFORDABILITY', publicMessage: 'Tu historial de ingresos no muestra la estabilidad requerida.', internalMessage: 'income_stability_score por debajo del umbral mínimo.', adverseAction: true },
  { code: 'DOWN_PAYMENT_INSUFFICIENT', category: 'AFFORDABILITY', publicMessage: 'El monto de cuota inicial ofrecido no cumple el mínimo requerido.', internalMessage: 'down_payment_amount por debajo del mínimo configurado del producto.', adverseAction: false },
  { code: 'LOAN_TO_VALUE_EXCEEDED', category: 'AFFORDABILITY', publicMessage: 'El monto solicitado excede el valor admisible del colateral ofrecido.', internalMessage: 'loan_to_value_ratio excede el máximo permitido por política.', adverseAction: true },
  { code: 'SELF_EMPLOYED_DOCUMENTATION_INCOMPLETE', category: 'AFFORDABILITY', publicMessage: 'Falta documentación de respaldo para ingresos independientes.', internalMessage: 'self_employed_flag=true sin tax_return_verified=true.', adverseAction: false },
];

const compliance: ReasonSeed[] = [
  { code: 'DISCLOSURE_NOT_ACKNOWLEDGED', category: 'COMPLIANCE', publicMessage: 'Debes confirmar la lectura de las divulgaciones antes de continuar.', internalMessage: 'No se registró aceptación de las divulgaciones regulatorias requeridas.', adverseAction: false },
  { code: 'COOLING_OFF_PERIOD_ACTIVE', category: 'COMPLIANCE', publicMessage: 'La solicitud se encuentra dentro del período de reflexión legal.', internalMessage: 'cooling_off_period_days aún vigente para una operación previa.', adverseAction: false },
  { code: 'MANDATORY_INSURANCE_MISSING', category: 'COMPLIANCE', publicMessage: 'Este producto requiere la contratación de un seguro obligatorio.', internalMessage: 'mandatory_insurance_required=true sin póliza asociada.', adverseAction: false },
  { code: 'INTEREST_RATE_CAP_VIOLATION', category: 'COMPLIANCE', publicMessage: 'La tasa calculada excede el tope legal aplicable.', internalMessage: 'Tasa propuesta excede usury_cap_rate de la jurisdicción.', adverseAction: true },
  { code: 'LICENSING_NOT_ACTIVE', category: 'COMPLIANCE', publicMessage: 'El producto no se encuentra disponible en este momento.', internalMessage: 'licensing_status distinto de LICENSED para la jurisdicción.', adverseAction: false },
  { code: 'CONSUMER_PROTECTION_REVIEW_REQUIRED', category: 'COMPLIANCE', publicMessage: 'Tu solicitud requiere una revisión adicional de cumplimiento.', internalMessage: 'consumer_protection_flag=true; requiere validación manual de cumplimiento.', adverseAction: false },
  { code: 'TAX_RESIDENCY_MISMATCH', category: 'COMPLIANCE', publicMessage: 'La información tributaria proporcionada requiere validación adicional.', internalMessage: 'tax_residency_country inconsistente con country_code declarado.', adverseAction: false },
  { code: 'REGULATORY_CATEGORY_RESTRICTED', category: 'COMPLIANCE', publicMessage: 'El producto solicitado no está disponible para tu perfil regulatorio.', internalMessage: 'product_regulatory_category restringida para el segmento del cliente.', adverseAction: true },
  { code: 'CROSS_BORDER_REVIEW_REQUIRED', category: 'COMPLIANCE', publicMessage: 'Tu solicitud requiere una revisión adicional por involucrar fondos internacionales.', internalMessage: 'cross_border_transaction_flag=true; requiere validación de cumplimiento.', adverseAction: false },
  { code: 'CURRENCY_NOT_SUPPORTED', category: 'COMPLIANCE', publicMessage: 'La moneda de la operación no está soportada para este producto.', internalMessage: 'currency_code fuera de las monedas habilitadas para la jurisdicción.', adverseAction: false },
];

const aml: ReasonSeed[] = [
  { code: 'AML_HIGH_RISK_RATING', category: 'AML', publicMessage: 'Tu solicitud requiere una revisión adicional de cumplimiento.', internalMessage: 'aml_risk_rating=HIGH; requiere debida diligencia reforzada.', adverseAction: false },
  { code: 'OFAC_POTENTIAL_MATCH', category: 'AML', publicMessage: 'Tu solicitud requiere una revisión adicional antes de continuar.', internalMessage: 'ofac_screening_result=POTENTIAL_MATCH; requiere resolución manual.', adverseAction: false },
  { code: 'SOURCE_OF_FUNDS_UNVERIFIED', category: 'AML', publicMessage: 'No fue posible verificar el origen de los fondos declarados.', internalMessage: 'source_of_funds_verified=false para el monto solicitado.', adverseAction: true },
  { code: 'HIGH_RISK_JURISDICTION', category: 'AML', publicMessage: 'Tu solicitud requiere una revisión adicional de cumplimiento.', internalMessage: 'high_risk_jurisdiction_flag=true; requiere debida diligencia reforzada.', adverseAction: false },
  { code: 'ADVERSE_MEDIA_FOUND', category: 'AML', publicMessage: 'Tu solicitud requiere una revisión adicional antes de continuar.', internalMessage: 'adverse_media_hit=true; requiere validación manual de cumplimiento.', adverseAction: false },
  { code: 'SHELL_COMPANY_SUSPECTED', category: 'AML', publicMessage: 'No fue posible completar la validación de la entidad solicitante.', internalMessage: 'shell_company_indicator=true sin beneficiario final identificado.', adverseAction: true },
  { code: 'STRUCTURING_PATTERN_DETECTED', category: 'AML', publicMessage: 'Tu solicitud requiere una revisión adicional de cumplimiento.', internalMessage: 'structuring_indicator=true; se deriva a investigación AML.', adverseAction: false },
  { code: 'AML_CASE_OPEN', category: 'AML', publicMessage: 'No es posible procesar la solicitud en este momento.', internalMessage: 'aml_case_open_flag=true para el cliente.', adverseAction: true },
  { code: 'CASH_INTENSIVE_BUSINESS_REVIEW', category: 'AML', publicMessage: 'Tu solicitud requiere una revisión adicional de cumplimiento.', internalMessage: 'cash_intensive_business_flag=true; requiere debida diligencia reforzada.', adverseAction: false },
  { code: 'BENEFICIAL_OWNER_UNRESOLVED', category: 'AML', publicMessage: 'No fue posible completar la validación de la entidad solicitante.', internalMessage: 'beneficial_owner_identified=false para una entidad no natural.', adverseAction: true },
];

const policy: ReasonSeed[] = [
  { code: 'APPROVED_POLICY', category: 'APPROVAL', publicMessage: 'Solicitud aprobada.', internalMessage: 'La solicitud cumplió KYC, fraude, elegibilidad y umbral de riesgo.', adverseAction: false },
  { code: 'APPROVED_WITH_CONDITIONS', category: 'APPROVAL', publicMessage: 'Solicitud aprobada sujeta a condiciones adicionales.', internalMessage: 'Aprobación condicionada a verificación posterior o cobertura de seguro.', adverseAction: false },
  { code: 'MANUAL_OVERRIDE_APPROVED', category: 'APPROVAL', publicMessage: 'Solicitud aprobada tras revisión manual.', internalMessage: 'Un analista autorizado aprobó la solicitud mediante override documentado.', adverseAction: false },
  { code: 'MANUAL_OVERRIDE_DECLINED', category: 'POLICY', publicMessage: 'No fue posible aprobar la solicitud tras la revisión manual.', internalMessage: 'Un analista autorizado rechazó la solicitud mediante override documentado.', adverseAction: true },
  { code: 'POLICY_VERSION_DEPRECATED', category: 'POLICY', publicMessage: 'No fue posible procesar la solicitud con la configuración vigente.', internalMessage: 'El artefacto de decisión activo fue retirado antes de completar la ejecución.', adverseAction: false },
  { code: 'CHAMPION_CHALLENGER_HOLDOUT', category: 'POLICY', publicMessage: 'Solicitud aprobada.', internalMessage: 'La solicitud fue asignada al grupo de control del experimento champion/challenger.', adverseAction: false },
  { code: 'SCORE_BAND_BORDERLINE', category: 'POLICY', publicMessage: 'La solicitud requiere una revisión adicional.', internalMessage: 'El puntaje calculado se encuentra en la banda de revisión manual.', adverseAction: false },
];

const operational: ReasonSeed[] = [
  { code: 'VARIABLE_MISSING_OR_INVALID', category: 'OPERATIONAL', publicMessage: 'No fue posible completar la evaluación con la información proporcionada.', internalMessage: 'Una o más variables requeridas no se resolvieron o fallaron su validación.', adverseAction: false },
  { code: 'EXTERNAL_PROVIDER_TIMEOUT', category: 'OPERATIONAL', publicMessage: 'No fue posible completar la evaluación en este momento; intenta nuevamente.', internalMessage: 'Un proveedor externo de datos no respondió dentro del tiempo configurado.', adverseAction: false },
  { code: 'DEPLOYMENT_SUSPENDED', category: 'OPERATIONAL', publicMessage: 'El servicio no está disponible en este momento; intenta nuevamente.', internalMessage: 'El despliegue activo del artefacto fue suspendido operativamente.', adverseAction: false },
  { code: 'MAX_EXECUTION_STEPS_EXCEEDED', category: 'OPERATIONAL', publicMessage: 'No fue posible completar la evaluación en este momento.', internalMessage: 'La ejecución del grafo excedió el número máximo de pasos configurado.', adverseAction: false },
  { code: 'IDEMPOTENCY_PAYLOAD_MISMATCH', category: 'OPERATIONAL', publicMessage: 'La solicitud ya fue procesada con datos distintos a los originales.', internalMessage: 'La clave de idempotencia fue reutilizada con un hash de payload diferente.', adverseAction: false },
  { code: 'RUNTIME_EXECUTION_FAILED', category: 'OPERATIONAL', publicMessage: 'No fue posible completar la evaluación en este momento; intenta nuevamente.', internalMessage: 'Error no controlado durante la ejecución del motor de decisión.', adverseAction: false },
];

export const reasonCodeCatalog: ReasonSeed[] = [
  ...kyc,
  ...fraud,
  ...creditRisk,
  ...eligibility,
  ...affordability,
  ...compliance,
  ...aml,
  ...policy,
  ...operational,
];
