import { Module } from '@nestjs/common';
import { ExpressionEvaluator } from './expression-evaluator';
import { GraphValidatorService } from './graph-validator.service';
import { CompilerService } from './compiler.service';
import { ExecutionEngineService } from './execution-engine.service';

@Module({
  providers: [ExpressionEvaluator, GraphValidatorService, CompilerService, ExecutionEngineService],
  exports: [ExpressionEvaluator, GraphValidatorService, CompilerService, ExecutionEngineService],
})
export class GraphModule {}
